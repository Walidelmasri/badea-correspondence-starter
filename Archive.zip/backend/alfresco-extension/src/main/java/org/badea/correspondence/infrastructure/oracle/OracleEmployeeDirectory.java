package org.badea.correspondence.infrastructure.oracle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.badea.correspondence.directory.DepartmentCode;
import org.badea.correspondence.directory.DepartmentDirectoryEntry;
import org.badea.correspondence.directory.DirectoryUsername;
import org.badea.correspondence.directory.EmployeeDirectory;
import org.badea.correspondence.directory.EmployeeDirectoryEntry;
import org.badea.correspondence.directory.EmployeeDirectoryException;
import org.badea.correspondence.directory.EmployeeId;

/**
 * Oracle-backed implementation of BADEA's employee directory.
 *
 * <p>Authentication remains Alfresco/AD-owned. This component only resolves
 * the authenticated directory username against BADEA's Oracle employee
 * directory and returns the canonical EMP_ID and employee metadata.</p>
 */
public final class OracleEmployeeDirectory implements EmployeeDirectory {

    private static final Log LOGGER =
        LogFactory.getLog(OracleEmployeeDirectory.class);

    private static final int LOOKUP_QUERY_TIMEOUT_SECONDS = 8;
    private static final long SLOW_LOOKUP_MILLIS = 2_000;

    // Transitional home-unit projection for existing single-role endpoints.
    // Authoritative manager/acting-manager rights come from Tarasol assignments.
    private static final String FIND_ACTIVE_BY_USERNAME_SQL = """
        SELECT
            e.EMP_ID AS EMPLOYEE_ID,
            e.USERID AS DIRECTORY_USER_ID,
            e.NAME_ENG AS EMPLOYEE_NAME_ENGLISH,
            e.NAME_ARABIC AS EMPLOYEE_NAME_ARABIC,
            e.DEPT_CODE AS EMPLOYEE_DEPARTMENT_CODE,
            d.UNIT_CODE AS DEPARTMENT_CODE,
            d.NAME_EN AS DEPARTMENT_NAME_ENGLISH,
            d.NAME_AR AS DEPARTMENT_NAME_ARABIC
        FROM BADEA_ADDONS.EMPLOYEES e
        LEFT JOIN TARASOL_ORG_UNITS d
            ON d.UNIT_CODE = e.DEPT_CODE
        WHERE e.ACTIVE = 1
          AND LOWER(
                CASE
                    WHEN INSTR(TRIM(e.USERID), '@') > 0
                    THEN SUBSTR(
                        TRIM(e.USERID),
                        1,
                        INSTR(TRIM(e.USERID), '@') - 1
                    )
                    ELSE TRIM(e.USERID)
                END
              ) = ?
        """;

    private static final String FIND_ACTIVE_BY_EMPLOYEE_ID_SQL = """
        SELECT e.EMP_ID AS EMPLOYEE_ID, e.USERID AS DIRECTORY_USER_ID,
               e.NAME_ENG AS EMPLOYEE_NAME_ENGLISH, e.NAME_ARABIC AS EMPLOYEE_NAME_ARABIC,
               e.DEPT_CODE AS EMPLOYEE_DEPARTMENT_CODE, d.UNIT_CODE AS DEPARTMENT_CODE,
               d.NAME_EN AS DEPARTMENT_NAME_ENGLISH, d.NAME_AR AS DEPARTMENT_NAME_ARABIC
        FROM BADEA_ADDONS.EMPLOYEES e
        LEFT JOIN TARASOL_ORG_UNITS d ON d.UNIT_CODE = e.DEPT_CODE
        WHERE e.ACTIVE = 1 AND e.EMP_ID = ?
        """;

    private static final String SEARCH_ACTIVE_SQL = """
        SELECT e.EMP_ID AS EMPLOYEE_ID, e.USERID AS DIRECTORY_USER_ID,
               e.NAME_ENG AS EMPLOYEE_NAME_ENGLISH, e.NAME_ARABIC AS EMPLOYEE_NAME_ARABIC,
               e.DEPT_CODE AS EMPLOYEE_DEPARTMENT_CODE, d.UNIT_CODE AS DEPARTMENT_CODE,
               d.NAME_EN AS DEPARTMENT_NAME_ENGLISH, d.NAME_AR AS DEPARTMENT_NAME_ARABIC
        FROM BADEA_ADDONS.EMPLOYEES e
        LEFT JOIN TARASOL_ORG_UNITS d ON d.UNIT_CODE = e.DEPT_CODE
        WHERE e.ACTIVE = 1
          AND (LOWER(TRIM(e.NAME_ENG)) LIKE ? ESCAPE '!'
               OR LOWER(TRIM(e.NAME_ARABIC)) LIKE ? ESCAPE '!'
               OR LOWER(CASE WHEN INSTR(TRIM(e.USERID), '@') > 0
                   THEN SUBSTR(TRIM(e.USERID), 1, INSTR(TRIM(e.USERID), '@') - 1)
                   ELSE TRIM(e.USERID) END) LIKE ? ESCAPE '!')
        ORDER BY e.NAME_ENG, e.EMP_ID
        FETCH FIRST 10 ROWS ONLY
        """;

    private final DataSource dataSource;

    public OracleEmployeeDirectory(DataSource dataSource) {
        this.dataSource = Objects.requireNonNull(
            dataSource,
            "Data source must not be null."
        );
    }

    @Override
    public Optional<EmployeeDirectoryEntry> findActiveByUsername(
        DirectoryUsername username
    ) {
        Objects.requireNonNull(
            username,
            "Directory username must not be null."
        );

        long startedNanos = System.nanoTime();
        long connectionAcquiredNanos = 0;

        try (
            Connection connection = dataSource.getConnection()
        ) {
            connectionAcquiredNanos = System.nanoTime();

            try (PreparedStatement statement =
                    connection.prepareStatement(FIND_ACTIVE_BY_USERNAME_SQL)) {
                statement.setQueryTimeout(LOOKUP_QUERY_TIMEOUT_SECONDS);
                statement.setString(1, username.value());

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (!resultSet.next()) {
                        return Optional.empty();
                    }

                    EmployeeDirectoryEntry employee =
                        mapEmployee(resultSet, username);

                    if (resultSet.next()) {
                        throw new EmployeeDirectoryException(
                            "Multiple active employee directory entries were "
                                + "found for username: "
                                + username.value()
                        );
                    }

                    return Optional.of(employee);
                }
            }
        } catch (SQLException exception) {
            throw new EmployeeDirectoryException(
                "Failed to query the employee directory.",
                exception
            );
        } finally {
            long elapsedMillis = TimeUnit.NANOSECONDS.toMillis(
                System.nanoTime() - startedNanos
            );
            if (elapsedMillis >= SLOW_LOOKUP_MILLIS) {
                long borrowMillis = connectionAcquiredNanos == 0
                    ? elapsedMillis
                    : TimeUnit.NANOSECONDS.toMillis(
                        connectionAcquiredNanos - startedNanos
                    );
                LOGGER.warn("Oracle employee lookup was slow; totalMs="
                    + elapsedMillis + ", connectionBorrowMs=" + borrowMillis);
            }
        }
    }

    @Override
    public Optional<EmployeeDirectoryEntry> findActiveByEmployeeId(EmployeeId employeeId) {
        Objects.requireNonNull(employeeId, "employeeId");
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_ACTIVE_BY_EMPLOYEE_ID_SQL)) {
            statement.setQueryTimeout(LOOKUP_QUERY_TIMEOUT_SECONDS);
            statement.setString(1, employeeId.value());
            try (ResultSet rows = statement.executeQuery()) {
                if (!rows.next()) return Optional.empty();
                String account = rows.getString("DIRECTORY_USER_ID");
                if (account == null || account.isBlank()) return Optional.empty();
                DirectoryUsername username = new DirectoryUsername(account);
                if (!username.value().matches("[a-z0-9][a-z0-9._-]{0,63}")) return Optional.empty();
                EmployeeDirectoryEntry entry = mapEmployee(rows, username);
                if (!employeeId.equals(entry.employeeId()) || rows.next()) {
                    throw new EmployeeDirectoryException("Ambiguous employee ID in Oracle directory");
                }
                return Optional.of(entry);
            }
        } catch (SQLException failure) {
            throw new EmployeeDirectoryException("Failed to resolve active employee by ID", failure);
        }
    }

    @Override
    public java.util.List<EmployeeDirectoryEntry> searchActive(String prefix) {
        if (prefix == null || prefix.trim().length() < 2 || prefix.trim().length() > 60) {
            throw new IllegalArgumentException("Search requires 2-60 characters.");
        }
        String escaped = prefix.trim().toLowerCase(java.util.Locale.ROOT)
                .replace("!", "!!").replace("%", "!%").replace("_", "!_");
        escaped = "%" + escaped + "%";
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(SEARCH_ACTIVE_SQL)) {
            statement.setQueryTimeout(LOOKUP_QUERY_TIMEOUT_SECONDS);
            statement.setString(1, escaped);
            statement.setString(2, escaped);
            statement.setString(3, escaped);
            java.util.List<EmployeeDirectoryEntry> matches = new java.util.ArrayList<>();
            try (ResultSet rows = statement.executeQuery()) {
                while (rows.next()) {
                    String account = rows.getString("DIRECTORY_USER_ID");
                    if (account == null || account.isBlank()) continue;
                    DirectoryUsername username = new DirectoryUsername(account);
                    if (!username.value().matches("[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}")) continue;
                    matches.add(mapEmployee(rows, username));
                }
            }
            return java.util.List.copyOf(matches);
        } catch (SQLException exception) {
            throw new EmployeeDirectoryException("Failed to search the employee directory.", exception);
        }
    }

    private EmployeeDirectoryEntry mapEmployee(
        ResultSet resultSet,
        DirectoryUsername resolvedUsername
    ) throws SQLException {
        try {
            EmployeeId employeeId = new EmployeeId(
                resultSet.getString("EMPLOYEE_ID")
            );

            String employeeNameEnglish =
                resultSet.getString("EMPLOYEE_NAME_ENGLISH");

            String employeeNameArabic =
                resultSet.getString("EMPLOYEE_NAME_ARABIC");

            Optional<DepartmentDirectoryEntry> department =
                mapDepartment(resultSet, employeeId);

            return new EmployeeDirectoryEntry(
                employeeId,
                resolvedUsername,
                employeeNameEnglish,
                employeeNameArabic,
                department
            );
        } catch (IllegalArgumentException | NullPointerException exception) {
            throw new EmployeeDirectoryException(
                "Employee directory contains invalid data for username: "
                    + resolvedUsername.value(),
                exception
            );
        }
    }

    private Optional<DepartmentDirectoryEntry> mapDepartment(
        ResultSet resultSet,
        EmployeeId employeeId
    ) throws SQLException {
        String employeeDepartmentCode =
            trimToNull(
                resultSet.getString("EMPLOYEE_DEPARTMENT_CODE")
            );

        if (employeeDepartmentCode == null) {
            return Optional.empty();
        }

        DepartmentCode departmentCode;

        try {
            departmentCode = new DepartmentCode(
                employeeDepartmentCode
            );
        } catch (IllegalArgumentException exception) {
            /*
             * BADEA's historical directory contains legacy non-numeric
             * department codes. They do not represent a current routable
             * department.
             */
            return Optional.empty();
        }

        String joinedDepartmentCode =
            trimToNull(
                resultSet.getString("DEPARTMENT_CODE")
            );

        if (joinedDepartmentCode == null) {
            // A valid employee may have an HR/SAP home department outside
            // Tarasol's 19 routable units. Preserve identity resolution;
            // never infer correspondence authority from that home code.
            return Optional.empty();
        }

        DepartmentDirectoryEntry department =
            new DepartmentDirectoryEntry(
                departmentCode,
                resultSet.getString(
                    "DEPARTMENT_NAME_ENGLISH"
                ),
                resultSet.getString(
                    "DEPARTMENT_NAME_ARABIC"
                )
            );

        return Optional.of(department);
    }

    private static String trimToNull(String value) {
        if (value == null) {
            return null;
        }

        String trimmed = value.trim();

        return trimmed.isEmpty()
            ? null
            : trimmed;
    }
}